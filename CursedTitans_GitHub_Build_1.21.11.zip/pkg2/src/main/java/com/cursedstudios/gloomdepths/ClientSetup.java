package com.cursedstudios.gloomdepths;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

@EventBusSubscriber(modid = Gloomdepths.MODID, value = Dist.CLIENT)
public final class ClientSetup {
    @SubscribeEvent
    @SuppressWarnings({"rawtypes", "unchecked"})
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        EntityRendererProvider<GloomCrawler> crawler = ctx -> new GeoEntityRenderer(ctx, Gloomdepths.CRAWLER.get());
        EntityRendererProvider<GloomWeaver> weaver = ctx -> new GeoEntityRenderer(ctx, Gloomdepths.WEAVER.get());
        EntityRendererProvider<AbyssColossus> boss = ctx -> new GeoEntityRenderer(ctx, Gloomdepths.COLOSSUS.get());
        e.registerEntityRenderer(Gloomdepths.CRAWLER.get(), crawler);
        e.registerEntityRenderer(Gloomdepths.WEAVER.get(), weaver);
        e.registerEntityRenderer(Gloomdepths.COLOSSUS.get(), boss);
    }
}
