package com.cursedstudios.gloomdepths;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animatable.manager.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.animation.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/** Boss: ground slam, summons crawlers at 66% and 33% health, enrages below a third. */
public class AbyssColossus extends Monster implements GeoEntity {
    private static final RawAnimation WALK = RawAnimation.begin().thenLoop("move.walk");
    private static final RawAnimation IDLE = RawAnimation.begin().thenLoop("misc.idle");
    private static final RawAnimation SLAM = RawAnimation.begin().thenPlay("attack.slam");
    private static final RawAnimation SWING = RawAnimation.begin().thenPlay("attack.swing");

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final ServerBossEvent bossEvent = new ServerBossEvent(
            Component.translatable("entity.gloomdepths.abyss_colossus"),
            BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.PROGRESS);

    private int slamCooldown = 120;
    private int slamWindup = -1;
    private boolean summoned66, summoned33, enraged;

    public AbyssColossus(EntityType<? extends AbyssColossus> type, Level level) {
        super(type, level);
        this.xpReward = 250;
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder attrs() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 300.0)
                .add(Attributes.ARMOR, 8.0)
                .add(Attributes.MOVEMENT_SPEED, 0.25)
                .add(Attributes.ATTACK_DAMAGE, 14.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
                .add(Attributes.FOLLOW_RANGE, 40.0);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0, true));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.6));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 16.0f));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public boolean doHurtTarget(ServerLevel level, Entity target) {
        boolean hit = super.doHurtTarget(level, target);
        if (hit) triggerAnim("Actions", "attack.swing");
        return hit;
    }

    @Override
    public boolean removeWhenFarAway(double distance) { return false; }

    @Override
    protected void customServerAiStep(ServerLevel level) {
        super.customServerAiStep(level);
        float frac = getHealth() / getMaxHealth();
        bossEvent.setProgress(frac);

        if (!summoned66 && frac <= 0.66f) { summoned66 = true; summonCrawlers(level); }
        if (!summoned33 && frac <= 0.33f) { summoned33 = true; summonCrawlers(level); }
        if (!enraged && frac <= 0.33f) {
            enraged = true;
            getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0.32);
            playSound(SoundEvents.WARDEN_ROAR, 3.0f, 0.7f);
        }

        LivingEntity target = getTarget();
        if (slamWindup >= 0) {
            if (--slamWindup == 0) doSlam(level);
        } else if (target != null && --slamCooldown <= 0 && distanceToSqr(target) < 9 * 9) {
            slamCooldown = enraged ? 90 : 150;
            slamWindup = 16;
            triggerAnim("Actions", "attack.slam");
            playSound(SoundEvents.WARDEN_ATTACK_IMPACT, 2.0f, 0.6f);
        }
    }

    private void doSlam(ServerLevel level) {
        double r = 7.0;
        AABB box = getBoundingBox().inflate(r, 2.0, r);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, x -> x != this && x.isAlive())) {
            e.hurtServer(level, level.damageSources().mobAttack(this), enraged ? 16.0f : 11.0f);
            Vec3 dir = e.position().subtract(position()).normalize();
            e.push(dir.x * 1.2, 0.7, dir.z * 1.2);
            e.hurtMarked = true;
        }
        for (int i = 0; i < 60; i++) {
            double a = i / 60.0 * Math.PI * 2;
            level.sendParticles(ParticleTypes.LARGE_SMOKE, getX() + Math.cos(a) * 5, getY() + 0.2, getZ() + Math.sin(a) * 5,
                    2, 0.2, 0.1, 0.2, 0.01);
        }
        playSound(SoundEvents.GENERIC_EXPLODE.value(), 3.0f, 0.6f);
    }

    private void summonCrawlers(ServerLevel level) {
        for (int i = 0; i < 3; i++) {
            double a = i / 3.0 * Math.PI * 2;
            BlockPos p = BlockPos.containing(getX() + Math.cos(a) * 4, getY(), getZ() + Math.sin(a) * 4);
            Gloomdepths.CRAWLER.get().spawn(level, p, EntitySpawnReason.MOB_SUMMONED);
        }
        playSound(SoundEvents.WARDEN_SONIC_BOOM, 2.0f, 0.8f);
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossEvent.removePlayer(player);
    }

    @Override
    protected SoundEvent getAmbientSound() { return SoundEvents.WARDEN_AMBIENT; }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.WARDEN_HURT; }

    @Override
    protected SoundEvent getDeathSound() { return SoundEvents.WARDEN_DEATH; }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(
                new AnimationController<AbyssColossus>("Move", 5,
                        t -> t.isMoving() ? t.setAndContinue(WALK) : t.setAndContinue(IDLE)),
                new AnimationController<AbyssColossus>("Actions", t -> PlayState.STOP)
                        .triggerableAnim("attack.slam", SLAM)
                        .triggerableAnim("attack.swing", SWING));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
