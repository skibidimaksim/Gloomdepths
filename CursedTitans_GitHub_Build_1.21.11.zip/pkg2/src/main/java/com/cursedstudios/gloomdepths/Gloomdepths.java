package com.cursedstudios.gloomdepths;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

@Mod(Gloomdepths.MODID)
public final class Gloomdepths {
    public static final String MODID = "gloomdepths";

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MODID);
    public static final DeferredRegister.Entities ENTITIES = DeferredRegister.createEntities(MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<GloomCrawler>> CRAWLER =
            ENTITIES.registerEntityType("gloom_crawler", GloomCrawler::new, MobCategory.MONSTER,
                    b -> b.sized(1.0f, 0.8f).clientTrackingRange(8));
    public static final DeferredHolder<EntityType<?>, EntityType<GloomWeaver>> WEAVER =
            ENTITIES.registerEntityType("gloom_weaver", GloomWeaver::new, MobCategory.MONSTER,
                    b -> b.sized(0.8f, 2.1f).clientTrackingRange(8));
    public static final DeferredHolder<EntityType<?>, EntityType<AbyssColossus>> COLOSSUS =
            ENTITIES.registerEntityType("abyss_colossus", AbyssColossus::new, MobCategory.MONSTER,
                    b -> b.sized(2.2f, 4.2f).fireImmune().clientTrackingRange(10));

    public static final DeferredItem<Item> GLOOM_SHARD = ITEMS.registerSimpleItem("gloom_shard");
    public static final DeferredItem<Item> WEAVER_ESSENCE = ITEMS.registerSimpleItem("weaver_essence");
    public static final DeferredItem<Item> ABYSS_HEART = ITEMS.registerSimpleItem("abyss_heart",
            new Item.Properties().rarity(Rarity.EPIC));
    public static final DeferredItem<SigilItem> ABYSS_SIGIL = ITEMS.registerItem("abyss_sigil", SigilItem::new,
            new Item.Properties().rarity(Rarity.RARE).stacksTo(1));
    public static final DeferredItem<Item> ABYSS_BLADE = ITEMS.registerItem("abyss_blade", Item::new,
            new Item.Properties().rarity(Rarity.EPIC).sword(ToolMaterial.NETHERITE, 4.0f, -2.4f));

    public static final DeferredItem<SpawnEggItem> CRAWLER_EGG = ITEMS.registerItem("gloom_crawler_spawn_egg",
            props -> new SpawnEggItem(props.spawnEgg(CRAWLER.get())));
    public static final DeferredItem<SpawnEggItem> WEAVER_EGG = ITEMS.registerItem("gloom_weaver_spawn_egg",
            props -> new SpawnEggItem(props.spawnEgg(WEAVER.get())));
    public static final DeferredItem<SpawnEggItem> COLOSSUS_EGG = ITEMS.registerItem("abyss_colossus_spawn_egg",
            props -> new SpawnEggItem(props.spawnEgg(COLOSSUS.get())));

    public Gloomdepths(IEventBus modBus) {
        ITEMS.register(modBus);
        ENTITIES.register(modBus);
        modBus.addListener(Gloomdepths::attributes);
        modBus.addListener(Gloomdepths::spawnPlacements);
        modBus.addListener(Gloomdepths::tabs);
    }

    private static void attributes(EntityAttributeCreationEvent e) {
        e.put(CRAWLER.get(), GloomCrawler.attrs().build());
        e.put(WEAVER.get(), GloomWeaver.attrs().build());
        e.put(COLOSSUS.get(), AbyssColossus.attrs().build());
    }

    private static void spawnPlacements(RegisterSpawnPlacementsEvent e) {
        e.register(CRAWLER.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                Monster::checkMonsterSpawnRules, RegisterSpawnPlacementsEvent.Operation.OR);
        e.register(WEAVER.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                Monster::checkMonsterSpawnRules, RegisterSpawnPlacementsEvent.Operation.OR);
    }

    private static void tabs(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
            e.accept(CRAWLER_EGG.get());
            e.accept(WEAVER_EGG.get());
            e.accept(COLOSSUS_EGG.get());
        } else if (e.getTabKey() == CreativeModeTabs.INGREDIENTS) {
            e.accept(GLOOM_SHARD.get());
            e.accept(WEAVER_ESSENCE.get());
            e.accept(ABYSS_HEART.get());
            e.accept(ABYSS_SIGIL.get());
        } else if (e.getTabKey() == CreativeModeTabs.COMBAT) {
            e.accept(ABYSS_BLADE.get());
        }
    }
}
